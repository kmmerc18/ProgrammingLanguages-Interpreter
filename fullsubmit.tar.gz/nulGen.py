f = open("nulTest.txt", "w+")
f.write("Inside this string is a \0 character")
f.close